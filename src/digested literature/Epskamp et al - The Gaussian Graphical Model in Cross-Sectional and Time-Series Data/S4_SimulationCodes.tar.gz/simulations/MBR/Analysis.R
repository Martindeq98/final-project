library("ggplot2")
library("dplyr")
library("psych")
library("qgraph")
library("tidyr")
library("WriteXLS")
library("gridExtra")

# Read output files:
files <- list.files(path = "OutputV6/", pattern  = "MBR_v6_", full.names = TRUE)
Data <- rbind_all(lapply(files,read.table, header=TRUE))


# Data to long format:
Gathered <- Data %>% 
  # select(nperson,ntime,temporal_cor,contemporaneous_cor,between_cor) %>%
  gather(key,value,temporal_cor:between_specificity) %>%
  mutate(type = gsub("_.*","",key), measure = gsub(".*_","",key), fixed = !grepl("random",key)) 

# Nicer labels:
Gathered$measure <- factor(Gathered$measure, levels= c("cor", "sensitivity", "specificity","bias","MSE")  ,labels = c("Correlation", "Sensitivity", "Specificity","Bias","Mean Squared\nError"))

### TABLE ###

# Format function for excel table:
meanFun <- function(x){
  mean <- mean(x,na.rm=TRUE)
  SD <- sd(x,na.rm=TRUE)
  paste0(format(round(mean, 2), nsmall = 2), " (",format(round(SD, 2), nsmall = 2),")")
}

# Make an excel table:
Summarized <- Data %>% select(estimation,nvar,rewireProb,temporalOffset,nperson,ntime,temporal_cor:between_specificity) %>%   group_by(estimation,nvar,rewireProb,temporalOffset,nperson,ntime) %>%
  summarize_each(funs(meanFun))

# Write to xls:
WriteXLS(Summarized,"TableFromR.xls")

### PLOTS ###

# Color-blind colors: 
cbbPalette <- c("#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

# Rename some labels:
Gathered$type2 <- paste0(Gathered$type," (",ifelse(Gathered$fixed,"fixed","individual"),")")
Gathered$type2 <- factor(Gathered$type2, 
                         levels = c("temporal (fixed)","contemporaneous (fixed)", "between (fixed)",
                                    "temporal (individual)", "contemporaneous (individual)"),
                         labels=c("Temporal\nfixed","Contemporaneous\nfixed", "Between-subjects\nfixed",
                                  "Temporal\nSubject-specific", "Contemporaneous\nSubject-specific")
)

Gathered$temporalOffset2 <- paste0("Condition: ", Gathered$temporalOffset)

# Legend function:
g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}


# Plot 1: mlVAR fixed structure, 8 nodes:
Filtered <- Gathered %>% filter(
  estimation == "mlVAR",
  rewireProb == 0,
  nvar == 8
)

# Construct the title:
Title <- "Two-step multi-level estimation (mlVAR)"
Sub <- "8-node networks, no rewiring (all subjects have same network structure)"

# Construct the plot:
g1 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))



# Plot 2: graphicalVAR fixed structure, 8 nodes:
Filtered <- Gathered %>% filter(
  estimation == "graphicalVAR",
  rewireProb == 0,
  nvar == 8
)

# Construct the title:
Title <- "Pooled and individual LASSO estimation (graphicalVAR)"
Sub <- "8-node networks, no rewiring (all subjects have same network structure)"

# Construct the plot:
g2 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))


# Plot 3: mlVAR fixed structure, 16 nodes:
Filtered <- Gathered %>% filter(
  estimation == "mlVAR",
  rewireProb == 0,
  nvar == 16
)

# Construct the title:
Title <- "Two-step multi-level estimation (mlVAR)"
Sub <- "16-node networks, no rewiring (all subjects have same network structure)"

# Construct the plot:
g3 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))


# Plot 4: graphicalVAR fixed structure, 16 nodes:
Filtered <- Gathered %>% filter(
  estimation == "graphicalVAR",
  rewireProb == 0,
  nvar == 16
)

# Construct the title:
Title <- "Pooled and individual LASSO estimation (graphicalVAR)"
Sub <- "16-node networks, no rewiring (all subjects have same network structure)"

# Construct the plot:
g4 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))

# Save to PDF:
pdf("simStudy_figures1.pdf",width = 7, height = 9)
print(g1)
print(g2)
print(g3)
print(g4)
dev.off()



######## FIG 2, NO COMMON STRUCTURE


# Plot 1: mlVAR fixed structure, 8 nodes:
Filtered <- Gathered %>% filter(
  estimation == "mlVAR",
  rewireProb == 0.5,
  nvar == 8,
  type2 %in% c( "Between-subjects\nfixed", "Temporal\nSubject-specific", "Contemporaneous\nSubject-specific"
  )
)

# Construct the title:
Title <- "mlVAR"
Sub <- "8-node networks, 50% rewiring"

# Construct the plot:
g1 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))


# Plot 2: graphicalVAR fixed structure, 8 nodes:
Filtered <- Gathered %>% filter(
  estimation == "graphicalVAR",
  rewireProb == 0.5,
  nvar == 8,
  type2 %in% c( "Between-subjects\nfixed", "Temporal\nSubject-specific", "Contemporaneous\nSubject-specific"
  )
)

# Construct the title:
Title <- "graphicalVAR"
Sub <- "8-node networks, 50% rewiring"

# Construct the plot:
g2 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))



# Plot 3: mlVAR fixed structure, 16 nodes:
Filtered <- Gathered %>% filter(
  estimation == "mlVAR",
  rewireProb == 0.5,
  nvar == 16,
  type2 %in% c( "Between-subjects\nfixed", "Temporal\nSubject-specific", "Contemporaneous\nSubject-specific"
  )
)

# Construct the title:
Title <- "mlVAR"
Sub <- "16-node networks, 50% rewiring"

# Construct the plot:
g3 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))


# Plot 4: graphicalVAR fixed structure, 8 nodes:
Filtered <- Gathered %>% filter(
  estimation == "graphicalVAR",
  rewireProb == 0.5,
  nvar == 16,
  type2 %in% c( "Between-subjects\nfixed", "Temporal\nSubject-specific", "Contemporaneous\nSubject-specific"
  )
)

# Construct the title:
Title <- "graphicalVAR"
Sub <- "16-node networks, 50% rewiring"

# Construct the plot:
g4 <- ggplot(Filtered, aes(x=factor(nperson), y =value, fill = factor(ntime))) + 
  facet_grid(measure + temporalOffset2~ type2) + 
  geom_boxplot(lwd=0.3, outlier.size = 0.1) + 
  theme_bw() + 
  xlab("Number of subjects") + 
  ylab("") + 
  scale_fill_manual("# Time",values=cbbPalette) + 
  scale_y_continuous(breaks = c(0,0.5,1),limits = c(0,1)) + 
  ggtitle(Title,subtitle = Sub) + 
  theme(legend.position = "bottom", strip.text.x = element_text(size = 8),
        strip.text.y = element_text(size = 6))

mylegend <- g_legend(g1)
# Save to PDF:
pdf("simStudy_figures2.pdf",width = 8, height = 9)

grid.arrange(arrangeGrob(g1 + theme(legend.position="none"),
                         g2 + theme(legend.position="none"),nrow=1), 
             mylegend, nrow=2,heights=c(10, 1))

grid.arrange(arrangeGrob(g3 + theme(legend.position="none"),
                         g4 + theme(legend.position="none"),nrow=1), 
             mylegend, nrow=2,heights=c(10, 1))

dev.off()


