#!/bin/bash
mkdir "$HOME"/Simulations/MBR/output
rm -r "$HOME"/Simulations/MBR/output/*.txt
rm -r "$TMPDIR"/MBR/*

for i in `seq 1 100`;
do
	sed s/iter/$i/g submit.sh > CUR_submit.sh
    qsub CUR_submit.sh
done







