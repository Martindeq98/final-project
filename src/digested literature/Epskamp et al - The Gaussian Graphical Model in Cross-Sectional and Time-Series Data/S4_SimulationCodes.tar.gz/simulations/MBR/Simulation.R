#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
if (length(args)==0){
  args <- 1
}

# Read the parSim function:
foo <- try(source("~/Simulations/parSim.R"))
if (methods::is(foo,"try-error")){
  source("../parSim.R")
}

# Function used to rewire edges:
rewire <- function(x,p,directed){
  if (missing(directed)){
    directed <- !all(x == t(x))
  }
  
  if (directed){
    ind <- diag(1,ncol(x)) != 1
  } else {
    ind <- upper.tri(x)
  }
  
  # Current edges:
  curEdges <- which(x!=0 & ind, arr.ind=TRUE)
  
  # Select to rewire:
  toRewire <- which(runif(nrow(curEdges)) < p)
  
  for (i in seq_along(toRewire)){
    curZeros <- which(x==0 & ind, arr.ind=TRUE)
    dest <- sample(seq_len(nrow(curZeros)),1)
    
    x[curZeros[dest,1],curZeros[dest,2]] <- x[curEdges[toRewire[i],1],curEdges[toRewire[i],2]]
    x[curEdges[toRewire[i],1],curEdges[toRewire[i],2]] <- 0
    
    if (!directed){
      x[curZeros[dest,2],curZeros[dest,1]] <- x[curEdges[toRewire[i],2],curEdges[toRewire[i],1]]
      x[curEdges[toRewire[i],2],curEdges[toRewire[i],1]] <- 0
    }
  }
  
  return(x)
}

## Simulator fuction:
simMLgvar <- function(
  ntime,
  Nvar,
  nperson,
  propPositive = 0.5,
  kappaMean = 0.3,
  kappaSD = 0.1, #c(0.25,0.5), #c(0.5,1),
  betaMean = 0.3,
  betaSD = 0.1, #c(0.25,0.5),
  betweenMean = 0.3,
  betweenSD = 0.1, #c(0.25,0.5),
  rewireWithin = 0,
  betweenVar = 1,
  withinVar = .25,
  temporalOffset = 2
){
  library("igraph")
  
  repeat{
    
    # Obtain true signed fixed structures:
    trueKappa <- as.matrix(get.adjacency(watts.strogatz.game(1,Nvar,1,0)))
    trueKappa[upper.tri(trueKappa)] <- trueKappa[upper.tri(trueKappa)] *  sample(c(-1,1),sum(upper.tri(trueKappa)),TRUE,prob=c(propPositive,1-propPositive))
    # Symmetrize:
    trueKappa[lower.tri(trueKappa)] <- t(trueKappa)[lower.tri(trueKappa)]  
    
    # Temporal effects:
    trueBeta <- diag(1,Nvar)
    for (i in 1:Nvar){
      trueBeta[(i+(temporalOffset-1))%%Nvar+1,i ] <- sample(c(-1,1),1,propPositive)
    }
    
    # Between subjects:
    trueBetween <- as.matrix(get.adjacency(watts.strogatz.game(1,Nvar,1,1)))
    trueBetween[upper.tri(trueBetween)] <- trueBetween[upper.tri(trueBetween)] *  sample(c(-1,1),sum(upper.tri(trueBetween)),TRUE,prob=c(propPositive,1-propPositive))
    # Parameterize:
    trueBetween[upper.tri(trueBetween)] <- rnorm(sum(upper.tri(trueBetween)),betweenMean,betweenSD) * trueBetween[upper.tri(trueBetween)]
    # Symmetrize:
    trueBetween[lower.tri(trueBetween)] <- t(trueBetween)[lower.tri(trueBetween)]  
    
    # Add diagonal:
    diag(trueBetween) <- 1
    
    # Check them all:
    evK <- round(eigen(trueKappa)$values,10)
    evB <- round(eigen(trueBeta)$values,10)
    evBet <- round(eigen(trueBetween)$values,10)
    
    if (all(evBet > 0)){
      break
    }
    
    
  }
  # Simulate means:
  Sigma <- cov2cor(solve(trueBetween))
  D <- diag(sqrt(betweenVar),Nvar)
  Means <- mvtnorm::rmvnorm(nperson,sigma = D%*%Sigma%*%D)
  
  # Simulate for every subject:
  SubjectData <- lapply(1:nperson,function(i){
    try <- 1
    maxtry <- 10
    repeat{
      kappa <- trueKappa
      kappa[upper.tri(kappa)] <- rnorm(sum(upper.tri(kappa)),kappaMean,kappaSD) * kappa[upper.tri(kappa)]
      # Symmetrize:
      kappa[lower.tri(kappa)] <- t(kappa)[lower.tri(kappa)]  
      diag(kappa) <- 1
      
      # Temporal:
      beta <- trueBeta * rnorm(Nvar^2, betaMean, betaSD)
      # diag(beta) <- Vmin
      
      # Rewire:
      kappa <- rewire(kappa,rewireWithin)
      beta <- rewire(beta,rewireWithin)
      
      evK <- eigen(kappa)$values
      evB <- eigen(beta)$values
      
      while(any(Re(evB)^2 + Im(evB)^2 > 1)){
        warning("Shrinking parameters")
        beta <- 0.95*beta
        evB <- eigen(beta)$values
      }
      
      
      if (all(evK > 0) & all(Re(evB)^2 + Im(evB)^2 < 1)){
        break
      }
      
      try <- try + 1
      if (try > maxtry){
        stop("Maximum number of tries reached.")
      }
    }
    
    D <- diag(sqrt(withinVar), Nvar)
    Delta <- diag(1/sqrt(diag(solve(kappa))))
    kappa <- solve(D)%*%solve(Delta)%*%kappa%*%solve(Delta)%*%solve(D)
    # Simulate data:
    Data <- as.data.frame(graphicalVARsim(ntime,beta,kappa,mean = Means[i,]))
    Data$ID <- i
    
    # Return:
    return(list(
      kappa=kappa,
      beta=beta,
      PCC = graphicalVAR:::computePCC(kappa),
      PDC = graphicalVAR:::computePDC(beta,kappa),
      data=Data
    ))
  })
  
  # Compute fixed effects:
  fixedKappa <- Reduce("+",lapply(SubjectData,"[[","kappa")) / nperson
  fixedBeta <- Reduce("+",lapply(SubjectData,"[[","beta")) / nperson
  
  # Aggregate data:
  allData <- do.call(rbind,lapply(SubjectData,"[[","data"))
  
  Results <- list(
    data = allData,
    fixedKappa = fixedKappa,
    fixedPCC = graphicalVAR:::computePCC(fixedKappa),
    fixedBeta = fixedBeta,
    fixedPDC = graphicalVAR:::computePDC(fixedBeta,fixedKappa),
    between = trueBetween,
    means=Means,
    personData = SubjectData,
    idvar = "ID",
    vars = names(allData)[names(allData)!="ID"]
  )
  
  class(Results) <- "simMLgvar"
  return(Results)
}


### SIMULATION SETUP ###
parSim(
  # Conditions:
  nvar = c(8, 16), #c(8,20), #6,
  nperson = c(50, 100, 200),
  ntime = c(50, 100, 200),
  gamma = 0.25,
  rewireProb = c(0, 0.5),
  weightSD= 0.1, #c(0, 0.15),
  weight = 0.35,
  temporalOffset = c(1,2),
  
  # Setup:
  name = paste0("MBR_v6_",args[1]),
  write=TRUE,
  nCores = 16,
  reps = 1,
  debug=FALSE,
  
  export = c("rewire","simMLgvar"),
  
  # The simulation code:
  expression = {
    if (nvar < 10){
      temporal <- c("correlated")
      contemporaneous <- c("correlated")
    } else {
      temporal <- c("orthogonal")
      contemporaneous <- c("orthogonal")
    }
    
    library("graphicalVAR")
    # For every network: correlation and average bias
    bias <- function(x,y) mean(abs(x-y),na.rm=TRUE)
    
    MSE <- function(x,y) mean((x-y)^2,na.rm=TRUE)
    
    
    cor0 <- function(x,y){
      if (all(is.na(x)) || all(is.na(y))){
        return(NA)
      }
      
      if (sd(x,na.rm=TRUE)==0 | sd(y,na.rm=TRUE) == 0){
        return(0)
      }
      
      return(cor(x,y,use="pairwise.complete.obs"))
    }
    
    
    # Function to compute sensitivity and specificity:
    CompareNetworks <- function(true,est, directed = TRUE){
      if (is.matrix(true) & is.matrix(est)){
        if (directed){
          real <- c(true)
          est <- c(est)
        } else {
          real <- true[upper.tri(true,diag=FALSE)]
          est <- est[upper.tri(est,diag=FALSE)]
        }        
      } else {
        real <- true
      }
      
      # True positives:
      TruePos <- sum(est != 0 &  real != 0)
      
      # False pos:
      FalsePos <- sum(est != 0 & real == 0)
      
      # True Neg:
      TrueNeg <- sum(est == 0 & real == 0)
      
      # False Neg:
      FalseNeg <- sum(est == 0 & real != 0)
      
      out <- list()
      
      ### Sensitivity:
      out$sensitivity <- TruePos / (TruePos + FalseNeg)
      
      # Specificity:
      out$specificity <- TrueNeg / (TrueNeg + FalsePos)
      
      # Correlation:
      out$Correlation <- cor0(est,real)
      
      out$Bias <- bias(est,real)
      
      out$MSE <- MSE(est,real)
      
      return(out)
    }
    
    # Packages to load:
    library("mlVAR")
    
    # Simulate model and data:
    Model <- simMLgvar(ntime = ntime,Nvar = nvar,nperson = nperson,
                       kappaMean = weight,
                       kappaSD = weightSD,
                       betaMean = weight,
                       betaSD = weightSD,
                       betweenMean = 0.35,
                       betweenSD = 0.1,
                       # kappaRange = c(weight-weightDiff,weight+weightDiff), 
                       # betaRange = c(weight-weightDiff,weight+weightDiff), 
                       # betweenRange = c(0.2,0.5),
                       rewireWithin = rewireProb,
                       temporalOffset=temporalOffset)
    
    fit <- mlVAR(Model$data, vars = Model$vars, idvar = Model$idvar, lags = 1,
                 temporal=temporal, verbose = FALSE, contemporaneous=contemporaneous)
    
    # obtain results:
    Results <- list()
    
    # Temporal:
    gTrue <- t(Model$fixedBeta)  #getNet(Model, "temporal")
    gEst <- getNet(fit, "temporal", nonsig = "hide", rule = "and")
    
    Temporal <- CompareNetworks(gTrue,gEst)
    
    Results[["temporal_cor"]] <- Temporal$Correlation
    Results[["temporal_bias"]] <- Temporal$Bias
    Results[["temporal_MSE"]] <- Temporal$MSE
    Results[["temporal_sensitivity"]] <- Temporal$sensitivity
    Results[["temporal_specificity"]] <- Temporal$specificity
    
    # obtain network of subject 1:
    gTrue <- t(Model$personData[[1]]$beta) 
    gEst <- getNet(fit, "temporal", nonsig = "hide", rule = "and", subject = 1)
    
    
    TemporalR <- CompareNetworks(gTrue,gEst)
    
    Results[["temporal_random_cor"]] <- TemporalR$Correlation
    Results[["temporal_random_bias"]] <- TemporalR$Bias
    Results[["temporal_random_MSE"]] <- TemporalR$MSE
    Results[["temporal_random_sensitivity"]] <- TemporalR$sensitivity
    Results[["temporal_random_specificity"]] <- TemporalR$specificity
   
    
    # Contemporaneous:
    gTrue <- Model$fixedPCC  #getNet(Model, "contemporaneous")
    gEst <- getNet(fit, "contemporaneous", nonsig = "hide", rule = "and")
    
    Contemporaneous <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results[["contemporaneous_cor"]] <- Contemporaneous$Correlation
    Results[["contemporaneous_bias"]] <- Contemporaneous$Bias
    
    Results[["contemporaneous_MSE"]] <- Contemporaneous$MSE
    
    Results[["contemporaneous_sensitivity"]] <- Contemporaneous$sensitivity
    Results[["contemporaneous_specificity"]] <- Contemporaneous$specificity
    
    
    # obtain network of subject 1:
    gTrue <- Model$personData[[1]]$PCC
    gEst <- getNet(fit, "contemporaneous", nonsig = "hide", rule = "and", subject = 1)
    
    
    ContemporaneousR <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results[["contemporaneous_random_cor"]] <- ContemporaneousR$Correlation
    Results[["contemporaneous_random_bias"]] <- ContemporaneousR$Bias
    Results[["contemporaneous_random_MSE"]] <- ContemporaneousR$MSE
    Results[["contemporaneous_random_sensitivity"]] <- ContemporaneousR$sensitivity
    Results[["contemporaneous_random_specificity"]] <- ContemporaneousR$specificity
    
    
    ### Between-subjects
    gTrue <- graphicalVAR:::computePCC(Model$between) #  getNet(Model, "between")
    gEst <- getNet(fit, "between", nonsig = "hide", rule = "and")
    
    Between <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results[["between_cor"]] <- Between$Correlation
    Results[["between_bias"]] <- Between$Bias
    
    Results[["between_MSE"]] <- Between$MSE
    
    Results[["between_sensitivity"]] <- Between$sensitivity
    Results[["between_specificity"]] <- Between$specificity
    
    ## Add mlVAR:
    Results$estimation <- "mlVAR"
    
    
    ### GraphicalVAR analysis
    library("graphicalVAR")
    Results_GVAR <- list()
    
    # Run analysis:
    outGVAR <- mlGraphicalVAR(Model$data,idvar = Model$idvar,gamma=gamma,nLambda=10,subjectNetworks = 1)
    
    
    # Temporal:
    gTrue <- t(Model$fixedBeta) #getNet(Model, "temporal")
    gEst <- t(outGVAR$fixedResults$beta[,-1])
    
    Temporal <- CompareNetworks(gTrue,gEst)
    
    Results_GVAR[["temporal_cor"]] <- Temporal$Correlation
    Results_GVAR[["temporal_bias"]] <- Temporal$Bias
    Results_GVAR[["temporal_MSE"]] <- Temporal$MSE
    
    Results_GVAR[["temporal_sensitivity"]] <- Temporal$sensitivity
    Results_GVAR[["temporal_specificity"]] <- Temporal$specificity
    
    
    # obtain network of subject 1:
    gTrue <- t(Model$personData[[1]]$beta) 
    gEst <- t(outGVAR$subjecResults[[1]]$beta[,-1])
    
    TemporalR <- CompareNetworks(gTrue,gEst)
    
    Results_GVAR[["temporal_random_cor"]] <- TemporalR$Correlation
    Results_GVAR[["temporal_random_bias"]] <- TemporalR$Bias
    
    Results_GVAR[["temporal_random_MSE"]] <- TemporalR$MSE
    
    Results_GVAR[["temporal_random_sensitivity"]] <- TemporalR$sensitivity
    Results_GVAR[["temporal_random_specificity"]] <- TemporalR$specificity
  
    
    # Contemporaneous:
    gTrue <- Model$fixedPCC # getNet(Model, "contemporaneous")
    gEst <- outGVAR$fixedResults$PCC
    diag(gEst) <- 0
    
    Contemporaneous <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results_GVAR[["contemporaneous_cor"]] <- Contemporaneous$Correlation
    Results_GVAR[["contemporaneous_bias"]] <- Contemporaneous$Bias
    
    Results_GVAR[["contemporaneous_MSE"]] <- Contemporaneous$MSE
    
    Results_GVAR[["contemporaneous_sensitivity"]] <- Contemporaneous$sensitivity
    Results_GVAR[["contemporaneous_specificity"]] <- Contemporaneous$specificity
    
    
    # obtain network of subject 1:
    gTrue <- Model$personData[[1]]$PCC
    gEst <- outGVAR$subjecResults[[1]]$PCC
    
    ContemporaneousR <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results_GVAR[["contemporaneous_random_cor"]] <- ContemporaneousR$Correlation
    Results_GVAR[["contemporaneous_random_bias"]] <- ContemporaneousR$Bias
    
    Results_GVAR[["contemporaneous_random_MSE"]] <- ContemporaneousR$MSE
    
    Results_GVAR[["contemporaneous_random_sensitivity"]] <- ContemporaneousR$sensitivity
    Results_GVAR[["contemporaneous_random_specificity"]] <- ContemporaneousR$specificity
    
  
    ### Between-subjects
    gTrue <- graphicalVAR:::computePCC(Model$between) # getNet(Model, "between")
    gEst <- outGVAR$betweenNet
    diag(gEst) <- 0
    
    Between <- CompareNetworks(gTrue,gEst,directed = FALSE)
    
    Results_GVAR[["between_cor"]] <- Between$Correlation
    Results_GVAR[["between_bias"]] <- Between$Bias
    
    Results_GVAR[["between_MSE"]] <- Between$MSE
    
    Results_GVAR[["between_sensitivity"]] <- Between$sensitivity
    Results_GVAR[["between_specificity"]] <- Between$specificity
    
    ## Add graphicalVAR:
    Results_GVAR$estimation <- "graphicalVAR"
    #Bind:
    allResults <- rbind(as.data.frame(Results),as.data.frame(Results_GVAR))
    
    allResults
  }) 

