#!/bin/bash

#PBS -N MBR
#PBS -lnodes=1
#PBS -lwalltime=24:00:00

module load openmpi/gnu
module load eb
module load R/3.3.1-intel-2016b
#export R_LIBS=$HOME/rpackages:$R_LIBS

cp -r "$HOME"/Simulations/MBR "$TMPDIR"
cd "$TMPDIR"/MBR

Rscript --vanilla Simulation.R iter

cp -r ./*.txt "$HOME"/Simulations/MBR/output





